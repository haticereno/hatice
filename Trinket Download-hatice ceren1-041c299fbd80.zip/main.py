alter=int(input("Alter: "))
note = int(input("Note:"))

if 20 <= alter <= 50 and note >80: 
  print("einstellen")
else:
  print("ablehnen")